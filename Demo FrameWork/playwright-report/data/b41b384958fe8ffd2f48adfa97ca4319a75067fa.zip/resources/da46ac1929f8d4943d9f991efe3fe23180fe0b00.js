
            self.onmessage = (event) => {
                if (event.data.message === 'start') {
                    try{
                        if (typeof self.OffscreenCanvas === 'undefined') {
                            return self.postMessage(-4);
                        }

                        const attributeName = event.data.attributeName;
                        const canvas = new OffscreenCanvas(1, 1);
                        const webgl2Context = canvas.getContext('webgl2');
                        const webglContext = canvas.getContext('webgl');
                        const context = webgl2Context || webglContext;

                        if (!context) {
                            return self.postMessage(-5);
                        }

                        const extension = context.getExtension('WEBGL_debug_renderer_info');

                        if (!extension) {
                            return self.postMessage(-2);
                        }

                        self.postMessage(context.getParameter(extension[attributeName]));
                    } catch(error){
                        return self.postMessage(-3);
                    }
                }
            }
        