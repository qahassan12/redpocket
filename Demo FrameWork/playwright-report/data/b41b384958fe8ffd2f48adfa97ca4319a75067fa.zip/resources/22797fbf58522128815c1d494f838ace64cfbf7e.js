
            self.onmessage = (event) => {
                if (event.data.message === 'start') {
                    try {
                        if (typeof self.OffscreenCanvas === 'undefined') {
                            return self.postMessage(-4);
                        }

                        const attributeName = event.data.attributeName;
                        const canvas = new OffscreenCanvas(1, 1);
                        const webgl2Context = canvas.getContext('webgl2');
                        const webglContext = canvas.getContext('webgl');
                        const resultContext = webgl2Context || webglContext;

                        if (!resultContext) {
                            return self.postMessage(-1);
                        }

                        const attribute = resultContext?.getParameter(resultContext[attributeName]);

                        if (!attribute) {
                            return self.postMessage(-2);
                        }

                        self.postMessage(attribute);
                    } catch(error) {
                        return self.postMessage(-3);
                    }
                }
            }
        