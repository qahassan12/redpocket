
        self.onmessage = (event) => {
            if(event.data !== 'start') return;
            let left = 0;
            let right = 1000;
            const step = 1000;
            const window = {};
            window.parent = window;
            let currentPath = 'window';
            try {
                while (true) {
                    currentPath += '.parent'.repeat(step);
                    eval(currentPath);
                    left = right;
                    right += step;
                }
            } catch (e) {
                void 0;
            }
            let deepestAccessibleParent = left;
            while (left <= right) {
                const mid = Math.floor((left + right) / 2);
                const testPath = 'window' + '.parent'.repeat(mid);
                try {
                    eval(testPath);
                    deepestAccessibleParent = mid;
                    left = mid + 1;
                } catch (e) {
                    right = mid - 1;
                }
            }
            for (let i = deepestAccessibleParent + 1; i <= right; i = i + 1) {
                try {
                    const testPath = 'window' + '.parent'.repeat(i);
                    eval(testPath);
                    deepestAccessibleParent = i;
                } catch (e) {
                    break;
                }
            }
            const result = Math.ceil(deepestAccessibleParent / 10) * 10;
            self.postMessage(result);
        }
    