
        self.onmessage = (event) => {
            if (event.data === 'start') {
                if (typeof self.OffscreenCanvas === 'undefined') {
                    return self.postMessage({ code: -4 });
                }

                const canvas = new OffscreenCanvas(220, 30);

                if (!canvas) {
                    return self.postMessage({ code: -3 });
                }

                const context = canvas?.getContext('2d');

                if (!context) {
                    return self.postMessage({ code: -2 });
                }

                drawCanvasImage(context);

                const imageAsUint8Array = context.getImageData(0,0,220,30).data;

                self.postMessage({ value: imageAsUint8Array });

                function drawCanvasImage(context) {
                    const text = 'Browser,Signal <canvas> 2.0';

                    context.textBaseline = 'top';
                    context.font = "14px 'Arial'";
                    context.textBaseline = 'alphabetic';
                    context.fillStyle = '#f60';
                    context.fillRect(125, 1, 62, 20);
                    context.fillStyle = '#069';
                    context.fillText(text, 2, 15);
                    context.fillStyle = 'rgba(102, 204, 0, 0.7)';
                    context.fillText(text, 4, 17);
                }
            }
        }
    